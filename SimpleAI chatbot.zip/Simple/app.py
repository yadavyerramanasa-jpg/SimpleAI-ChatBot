import streamlit as st
import os
import io
from datetime import datetime
from PIL import Image

# --- 1. LIFE-CYCLE EXPLICIT WRAPPERS ---
try:
    from google import genai
    from google.genai import types  
    from google.genai.errors import APIError
    HAS_GEMINI = True
except ImportError:
    HAS_GEMINI = False

try:
    import speech_recognition as sr
    HAS_SPEECH = True
except Exception:
    HAS_SPEECH = False

try:
    from gtts import gTTS
    HAS_GTTS = True
except ImportError:
    HAS_GTTS = False

# 🔑 PASTE YOUR GOOGLE AI STUDIO API KEY HERE:
GEMINI_API_KEY = "AQ.Ab8RN6JMuBLlDm3HswzuevbOrzA6ONEqU66u1RoIGDOjBPVLsg"

@st.cache_resource
def load_llm_client():
    if not HAS_GEMINI:
        return None
    if "YOUR_GEMINI_API_KEY" in GEMINI_API_KEY or len(GEMINI_API_KEY) < 10:
        return None
    try:
        return genai.Client(api_key=GEMINI_API_KEY)
    except Exception:
        return None

client = load_llm_client()

# --- 2. MULTIMEDIA DRIVER UTILITIES ---
def capture_audio_input():
    if not HAS_SPEECH:
        return None
    r = sr.Recognizer()
    try:
        with sr.Microphone() as source:
            st.toast("Listening... Speak clearly now!", icon="🎙️")
            r.adjust_for_ambient_noise(source, duration=0.5)
            audio = r.listen(source, timeout=4, phrase_time_limit=8)
            return r.recognize_google(audio)
    except Exception:
        st.toast("⚠️ Audio capture failed or timed out.", icon="❌")
    return None

def convert_text_to_audio(text_content):
    if not HAS_GTTS:
        return None
    try:
        clean_text = text_content.replace("`", "").replace("*", "").replace("#", "")
        tts = gTTS(text=clean_text[:200], lang='en', slow=False)
        audio_buffer = io.BytesIO()
        tts.write_to_fp(audio_buffer)
        audio_buffer.seek(0)
        return audio_buffer
    except Exception:
        return None

# --- 3. FRONTEND GRAPHICAL STYLING & INTERFACE ---
st.set_page_config(page_title="Nexus Pro Workspace", page_icon="🧠", layout="centered")

# Custom HTML/CSS Injector for custom bubble colors, padding, avatars, and alignments
st.markdown("""
    <style>
    .chat-container { display: flex; align-items: flex-start; margin-bottom: 5px; padding: 15px; border-radius: 12px; }
    .user-bubble { background-color: #1E3A8A; color: #FFFFFF; border-left: 5px solid #3B82F6; }
    .model-bubble { background-color: #2D3748; color: #E2E8F0; border-left: 5px solid #10B981; }
    .avatar-zone { font-size: 2rem; margin-right: 15px; display: flex; align-items: center; justify-content: center; }
    .content-zone { flex: 1; }
    .timestamp-label { font-size: 0.75rem; color: #A0AEC0; margin-top: 8px; display: block; text-align: right; }
    </style>
""", unsafe_allow_html=True)

st.title("🧠 Nexus Pro AI Workspace")
st.caption("Advanced Engine: ChatGPT Chat Bar Layout with Message Editing & Deletion Controls")

# Initialize Session Memory States securely
if "chat_history" not in st.session_state:
    st.session_state.chat_history = [
        {
            "role": "model", 
            "content": "Hello! I am Nexus Pro. Ask me to write code, solve problems, or process visual assets!",
            "time": datetime.now().strftime("%I:%M %p")
        }
    ]

if "active_image_bytes" not in st.session_state:
    st.session_state.active_image_bytes = None

if "editing_index" not in st.session_state:
    st.session_state.editing_index = None

# --- SIDEBAR HISTORY MANAGEMENT ---
with st.sidebar:
    st.header("⚙️ Workspace Controls")
    if st.button("🗑️ Reset Chat Canvas", use_container_width=True):
        st.session_state.chat_history = [{"role": "model", "content": "Canvas cleared!", "time": datetime.now().strftime("%I:%M %p")}]
        st.session_state.active_image_bytes = None
        st.session_state.editing_index = None
        st.rerun()
    
    st.markdown("---")
    st.subheader("📜 Chat History Logs")
    user_prompts_index = [msg["content"] for msg in st.session_state.chat_history if msg["role"] == "user"]
    
    if user_prompts_index:
        for idx, prompt in enumerate(reversed(user_prompts_index)):
            snippet = prompt if len(prompt) < 30 else f"{prompt[:27]}..."
            st.markdown(f"**💬 Log {len(user_prompts_index) - idx}:**\n> {snippet}")
    else:
        st.caption("No conversations logged yet.")

    st.markdown("---")
    st.write("**Hardware Status:**")
    st.write("🎙️ Voice Capture Driver:", "✅ Online" if HAS_SPEECH else "⚠️ Offline")
    st.write("🔊 Speech Synthesizer:", "✅ Online" if HAS_GTTS else "⚠️ Offline")

# Display Library Diagnostic Errors if conditions trigger
if not HAS_GEMINI:
    st.error("❌ Core module missing! Run: `pip install google-genai` inside terminal layout environment.")
elif client is None:
    st.error("🔑 API Key Missing! Setup your key on Line 31 of this script configuration.")

# --- MULTIMEDIA EXTRACTION PORTAL ZONE (UPLOADER & CAMERA) ---
st.write("### 🖼️ Visual Context Channels")
upload_tab, camera_tab = st.tabs(["📁 File Uploader", "📸 Live Capture Camera"])
raw_file_bytes = None

with upload_tab:
    uploaded_file = st.file_uploader("Upload static reference configuration", type=["png", "jpg", "jpeg"], key="static_upload")
    if uploaded_file is not None:
        raw_file_bytes = uploaded_file.read()

with camera_tab:
    camera_file = st.camera_input("Capture live visual asset setup reference")
    if camera_file is not None:
        raw_file_bytes = camera_file.read()

# Protect visual bytes across continuous reloads inside state memory placeholders
if raw_file_bytes:
    st.session_state.active_image_bytes = raw_file_bytes

if st.session_state.active_image_bytes:
    try:
        display_preview = Image.open(io.BytesIO(st.session_state.active_image_bytes))
        st.image(display_preview, caption="📸 Active Visual Context Loaded", width=250)
    except Exception as e:
        st.error(f"Image processing error: {e}")

# --- TIMELINE RENDER LOOP WITH EDIT & DELETE ACTIONS ---
for idx, message in enumerate(st.session_state.chat_history):
    is_user = message["role"] == "user"
    bubble_class = "user-bubble" if is_user else "model-bubble"
    avatar_icon = "👤" if is_user else "🤖"
    
    st.markdown(f"""
        <div class="chat-container {bubble_class}">
            <div class="avatar-zone">{avatar_icon}</div>
            <div class="content-zone">
                <div>{message["content"]}</div>
                <span class="timestamp-label">⏱️ {message["time"]}</span>
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    if "audio_stream" in message and message["audio_stream"] is not None:
        st.audio(message["audio_stream"], format="audio/mp3")

    # Render Action Toolbar below active user bubbles
    if is_user:
        edit_col, delete_col, space_col = st.columns([1, 1, 5])
        
        with edit_col:
            if st.button("✏️ Edit", key=f"edit_trigger_{idx}"):
                st.session_state.editing_index = idx
                st.rerun()
                
        with delete_col:
            if st.button("🗑️ Delete", key=f"delete_trigger_{idx}"):
                # To clean up seamlessly, remove the message and the AI reply immediately following it
                if idx + 1 < len(st.session_state.chat_history) and st.session_state.chat_history[idx + 1]["role"] == "model":
                    del st.session_state.chat_history[idx + 1]
                del st.session_state.chat_history[idx]
                
                # Clear any lingering editing selections
                st.session_state.editing_index = None
                st.rerun()
        
        # Display localized inline modification workspace inputs
        if st.session_state.editing_index == idx:
            with st.container():
                edited_text = st.text_input("Modify message and press Enter:", value=message["content"], key=f"edit_field_{idx}")
                save_col, cancel_col = st.columns([1, 5])
                
                with save_col:
                    if st.button("💾 Save", key=f"save_btn_{idx}"):
                        if edited_text.strip() and edited_text != message["content"]:
                            st.session_state.chat_history[idx]["content"] = edited_text
                            st.session_state.chat_history[idx]["time"] = datetime.now().strftime("%I:%M %p (Edited)")
                            
                            # Slice off subsequent responses to regenerate cleaner contextual threads forward
                            st.session_state.chat_history = st.session_state.chat_history[:idx + 1]
                            st.session_state["trigger_query"] = edited_text
                            
                        st.session_state.editing_index = None
                        st.rerun()
                        
                with cancel_col:
                    if st.button("❌ Cancel", key=f"cancel_btn_{idx}"):
                        st.session_state.editing_index = None
                        st.rerun()

st.markdown("---")

# --- 4. DATA PROCESSING RUNTIME INTERACTION ENGINE ---
active_prompt = None

# Listen for structural updates triggered by message modification channels
if "trigger_query" in st.session_state and st.session_state["trigger_query"] is not None:
    active_prompt = st.session_state["trigger_query"]
    del st.session_state["trigger_query"]

# Optional Dictation Control Row sitting right above the sticky Chat Bar baseline
if HAS_SPEECH and active_prompt is None:
    if st.button("🎙️ Click to Dictate via Microphone", use_container_width=True):
        if spoken_text := capture_audio_input():
            active_prompt = spoken_text

# Primary Full-Width Pinned Chat Bar Sendbox 
text_query = st.chat_input("✨ Write a message or ask a question...")
if text_query:
    active_prompt = text_query

# Core runtime evaluation
if active_prompt:
    if not client:
        st.error("Execution blocked: Insert your valid Gemini API signature key on line 31.")
    else:
        # Avoid appending duplicate records if running an automated update flow loop
        if len(st.session_state.chat_history) == 0 or st.session_state.chat_history[-1]["content"] != active_prompt:
            current_time_str = datetime.now().strftime("%I:%M %p")
            st.session_state.chat_history.append({
                "role": "user", 
                "content": active_prompt,
                "time": current_time_str
            })

        # Process payload parameters safely from continuous state wrappers
        payload_container = []
        if st.session_state.active_image_bytes:
            image_part = types.Part.from_bytes(data=st.session_state.active_image_bytes, mime_type="image/jpeg")
            payload_container.append(image_part)
            
        payload_container.append(active_prompt)

        with st.spinner("Processing solutions structure..."):
            try:
                response = client.models.generate_content(
                    model='gemini-2.5-flash',
                    contents=payload_container
                )
                ai_reply = response.text
            except APIError as cloud_err:
                ai_reply = f"❌ Gemini API Cloud Error: {str(cloud_err)}"
            except Exception as system_err:
                ai_reply = f"❌ Internal system mapping error: {str(system_err)}"

        vocal_playback = convert_text_to_audio(ai_reply)

        response_payload = {
            "role": "model", 
            "content": ai_reply,
            "time": datetime.now().strftime("%I:%M %p")
        }
        if vocal_playback:
            response_payload["audio_stream"] = vocal_playback
            
        st.session_state.chat_history.append(response_payload)
        
        # Flush uploaded/captured media data after processing complete to accept new variables cleanly
        st.session_state.active_image_bytes = None
        st.rerun()