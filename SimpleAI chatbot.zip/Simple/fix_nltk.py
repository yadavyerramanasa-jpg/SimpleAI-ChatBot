import nltk
import ssl

# Bypass SSL certificate verification if your network/wifi is blocking the download
try:
    _create_unverified_https_context = ssl._create_unverified_context
except AttributeError:
    pass
else:
    ssl._create_default_https_context = _create_unverified_https_context

print("Downloading required NLTK packages...")
nltk.download('punkt')
nltk.download('punkt_tab') # Required in newer NLTK versions
nltk.download('wordnet')
nltk.download('omw-1.4')

print("Done! All packages downloaded successfully.")